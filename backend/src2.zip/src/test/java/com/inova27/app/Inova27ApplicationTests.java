package com.inova27.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Inova27ApplicationTests {

	@Test
	void contextLoads() {
	}

}
