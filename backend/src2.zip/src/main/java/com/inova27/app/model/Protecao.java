package com.inova27.app.model;

import jakarta.annotation.PreDestroy;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "protecoes")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Protecao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_patente")
    private Long id;

    private String codId;

    @Column(nullable = false, length = 200)
    private String nome;

    @Column(length = 1000)
    private String resumo;

    @Column(length = 150)
    private String instituicao;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private NaturezaProtecao natureza;

    @Column(name = "data_deposito")
    private LocalDate dataDeposito;

    @Column(name = "info_extra", length = 1000)
    private String infoExtra;

    @ElementCollection(targetClass = TipoProtecao.class)
    @CollectionTable(
            name = "protecao_tipos",
            joinColumns = @JoinColumn(name = "protecao_id")
    )
    @Enumerated(EnumType.STRING)
    @Column(name = "tipo")
    private Set<TipoProtecao> tipos = new HashSet<>();

    // 🔹 Relacionamento N:1 (Protecao -> Tecnologia)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tecnologia_id")
    private Tecnologia tecnologia;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "jogo_id")
    private Jogo jogo;

    @PrePersist
    @PreUpdate
    @PreDestroy
    private void validarVinculos() {
        if (this.tecnologia == null && this.jogo == null) {
            throw new IllegalStateException("Falha de Integridade: Uma proteção não pode ficar órfã. Ela deve estar vinculada a pelo menos uma Tecnologia ou um Jogo.");
        }
    }
}