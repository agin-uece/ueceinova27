package com.inova27.app.dto.tecnologia;

public record TecnologiaUpdateDTO(
        String nome,
        String descricao,
        String area,
        String nivelMaturidade,
        String aplicacao,
        String status
) {}