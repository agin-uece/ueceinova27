package com.inova27.app.controller;

import com.inova27.app.dto.protecao.ProtecaoCreateDTO;
import com.inova27.app.dto.protecao.ProtecaoResponseDTO;
import com.inova27.app.dto.protecao.ProtecaoUpdateDTO;
import com.inova27.app.service.ProtecaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/protecoes")
public class ProtecaoController {

    @Autowired
    private ProtecaoService service;

    // 🔹 CREATE (POST)
    @PostMapping
    public ResponseEntity<?> criar(@RequestBody ProtecaoCreateDTO dto) {
        try {
            ProtecaoResponseDTO novaProtecao = service.criar(dto);
            return ResponseEntity
                    .created(URI.create("/api/protecoes/" + novaProtecao.id()))
                    .body(novaProtecao); // 201 Created
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("erro", e.getMessage())); // 400
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Ocorreu um erro ao processar a requisição.")); // 500
        }
    }

    // 🔹 READ ALL (GET)
    @GetMapping
    public ResponseEntity<?> listarTodas() {
        try {
            List<ProtecaoResponseDTO> protecoes = service.listarTodas();
            return ResponseEntity.ok(protecoes); // 200 OK
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao buscar a lista de proteções."));
        }
    }

    // 🔹 READ BY ID (GET)
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        try {
            ProtecaoResponseDTO protecao = service.buscarPorId(id);
            return ResponseEntity.ok(protecao); // 200 OK
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro interno ao buscar proteção."));
        }
    }

    // 🔹 UPDATE (PUT)
    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @RequestBody ProtecaoUpdateDTO dto) {
        try {
            ProtecaoResponseDTO protecaoAtualizada = service.atualizar(id, dto);
            return ResponseEntity.ok(protecaoAtualizada); // 200 OK
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao atualizar os dados da proteção."));
        }
    }

    // 🔹 DELETE (DELETE)
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        try {
            service.deletar(id);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build(); // 204 No Content
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao excluir a proteção."));
        }
    }

    // ========================================================================
    // 🔹 ENDPOINTS DE RELACIONAMENTOS
    // ========================================================================

    // 🎮 JOGOS
    @PutMapping("/{protecaoId}/jogo/{jogoId}")
    public ResponseEntity<?> vincularJogo(@PathVariable Long protecaoId, @PathVariable Long jogoId) {
        try {
            service.vincularJogo(protecaoId, jogoId);
            return ResponseEntity.ok(Map.of("mensagem", "Jogo vinculado com sucesso à proteção."));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", e.getMessage()));
        }
    }

    @DeleteMapping("/{protecaoId}/jogo/{jogoId}")
    public ResponseEntity<?> desvincularJogo(@PathVariable Long protecaoId, @PathVariable Long jogoId) {
        try {
            service.desvincularJogo(protecaoId, jogoId);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", e.getMessage()));
        }
    }
}