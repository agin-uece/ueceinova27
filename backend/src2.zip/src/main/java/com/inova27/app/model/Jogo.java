package com.inova27.app.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "jogos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Jogo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_game")
    private Long id;

    @Column(nullable = false, length = 150)
    private String nome;

    @Column(length = 1000)
    private String descricao;

    @Enumerated(EnumType.STRING)
    private GeneroJogo genero;

    @Enumerated(EnumType.STRING)
    private Plataforma plataforma;

    @Column(name = "data_lancamento")
    private LocalDate dataLancamento;

    @Column(name = "link_download", length = 300)
    private String linkDownload;

    @Column(length = 200)
    private String site;

    // 🔹 Relacionamento 1:N (Jogo -> Protecao)
    @OneToMany(mappedBy = "jogo", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Protecao> protecoes = new HashSet<>();

    // 🔹 Tecnologias usadas (N:N com Tecnologia)
    @ManyToMany
    @JoinTable(
            name = "jogo_tecnologia",
            joinColumns = @JoinColumn(name = "jogo_id"),
            inverseJoinColumns = @JoinColumn(name = "tecnologia_id")
    )
    private Set<Tecnologia> tecnologias = new HashSet<>();
}