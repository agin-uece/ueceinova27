package com.inova27.app.controller;

import com.inova27.app.dto.jogo.JogoCreateDTO;
import com.inova27.app.dto.jogo.JogoResponseDTO;
import com.inova27.app.dto.jogo.JogoUpdateDTO;
import com.inova27.app.service.JogoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/jogos")
public class JogoController {

    @Autowired
    private JogoService service;

    // 🔹 CREATE (POST)
    @PostMapping
    public ResponseEntity<?> criar(@RequestBody JogoCreateDTO dto) {
        try {
            JogoResponseDTO novoJogo = service.criar(dto);
            return ResponseEntity
                    .created(URI.create("/api/jogos/" + novoJogo.id()))
                    .body(novoJogo); // 201 Created
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("erro", e.getMessage())); // 400
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Ocorreu um erro ao processar a requisição.")); // 500
        }
    }

    // 🔹 READ ALL (GET)
    @GetMapping
    public ResponseEntity<?> listarTodos() {
        try {
            List<JogoResponseDTO> jogos = service.listarTodos();
            return ResponseEntity.ok(jogos); // 200 OK
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao buscar a lista de jogos.")); // 500
        }
    }

    // 🔹 READ BY ID (GET)
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        try {
            JogoResponseDTO jogo = service.buscarPorId(id);
            return ResponseEntity.ok(jogo); // 200 OK
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro interno ao buscar jogo.")); // 500
        }
    }

    // 🔹 UPDATE (PUT)
    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @RequestBody JogoUpdateDTO dto) {
        try {
            JogoResponseDTO jogoAtualizado = service.atualizar(id, dto);
            return ResponseEntity.ok(jogoAtualizado); // 200 OK
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao atualizar os dados do jogo.")); // 500
        }
    }

    // 🔹 DELETE (DELETE)
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        try {
            service.deletar(id);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build(); // 204 No Content
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao excluir o jogo.")); // 500
        }
    }
}