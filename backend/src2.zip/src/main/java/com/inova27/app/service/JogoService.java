package com.inova27.app.service;

import com.inova27.app.dto.jogo.JogoCreateDTO;
import com.inova27.app.dto.jogo.JogoResponseDTO;
import com.inova27.app.dto.jogo.JogoUpdateDTO;
import com.inova27.app.model.Jogo;
import com.inova27.app.repository.JogoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class JogoService {

    @Autowired
    private JogoRepository repository;

    // 🔹 CREATE
    public JogoResponseDTO criar(JogoCreateDTO dto) {
        try {
            if (dto.nome() == null || dto.nome().isBlank()) {
                throw new IllegalArgumentException("O nome do jogo é obrigatório.");
            }
            if (repository.existsByNome(dto.nome())) {
                throw new IllegalArgumentException("Já existe um jogo cadastrado com este nome.");
            }

            Jogo jogo = new Jogo();
            jogo.setNome(dto.nome());
            jogo.setDescricao(dto.descricao());
            jogo.setGenero(dto.genero());
            jogo.setPlataforma(dto.plataforma());
            jogo.setDataLancamento(dto.dataLancamento());
            jogo.setLinkDownload(dto.linkDownload());
            jogo.setSite(dto.site());

            Jogo salvo = repository.save(jogo);
            return toResponseDTO(salvo);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao criar jogo: " + e.getMessage());
        }
    }

    // 🔹 READ ALL
    public List<JogoResponseDTO> listarTodos() {
        try {
            return repository.findAll()
                    .stream()
                    .map(this::toResponseDTO)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar a lista de jogos: " + e.getMessage());
        }
    }

    // 🔹 READ BY ID
    public JogoResponseDTO buscarPorId(Long id) {
        try {
            Jogo jogo = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Jogo não encontrado com o ID: " + id));
            return toResponseDTO(jogo);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao buscar jogo: " + e.getMessage());
        }
    }

    // 🔹 UPDATE
    public JogoResponseDTO atualizar(Long id, JogoUpdateDTO dto) {
        try {
            Jogo jogo = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Jogo não encontrado para atualização."));

            if (dto.nome() != null && !dto.nome().isBlank()) jogo.setNome(dto.nome());
            if (dto.descricao() != null) jogo.setDescricao(dto.descricao());
            if (dto.genero() != null) jogo.setGenero(dto.genero());
            if (dto.plataforma() != null) jogo.setPlataforma(dto.plataforma());
            if (dto.dataLancamento() != null) jogo.setDataLancamento(dto.dataLancamento());
            if (dto.linkDownload() != null) jogo.setLinkDownload(dto.linkDownload());
            if (dto.site() != null) jogo.setSite(dto.site());

            Jogo atualizado = repository.save(jogo);
            return toResponseDTO(atualizado);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao atualizar jogo: " + e.getMessage());
        }
    }

    // 🔹 DELETE
    public void deletar(Long id) {
        try {
            Jogo jogo = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Jogo não encontrado para exclusão."));

            repository.delete(jogo);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao deletar jogo: " + e.getMessage());
        }
    }

    // 🔹 MAPPER
    private JogoResponseDTO toResponseDTO(Jogo jogo) {
        return new JogoResponseDTO(
                jogo.getId(),
                jogo.getNome(),
                jogo.getDescricao(),
                jogo.getGenero(),
                jogo.getPlataforma(),
                jogo.getDataLancamento(),
                jogo.getLinkDownload(),
                jogo.getSite()
        );
    }
}