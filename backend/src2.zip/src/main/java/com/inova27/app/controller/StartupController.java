package com.inova27.app.controller;

import com.inova27.app.dto.startup.StartupCreateDTO;
import com.inova27.app.dto.startup.StartupResponseDTO;
import com.inova27.app.dto.startup.StartupUpdateDTO;
import com.inova27.app.service.StartupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/startups")
public class StartupController {

    @Autowired
    private StartupService service;

    // 🔹 CREATE (POST)
    @PostMapping
    public ResponseEntity<?> criar(@RequestBody StartupCreateDTO dto) {
        try {
            StartupResponseDTO novaStartup = service.criar(dto);
            return ResponseEntity
                    .created(URI.create("/api/startups/" + novaStartup.id()))
                    .body(novaStartup); // 201 Created
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("erro", e.getMessage())); // 400
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Ocorreu um erro ao processar a requisição.")); // 500
        }
    }

    // 🔹 READ ALL (GET)
    @GetMapping
    public ResponseEntity<?> listarTodas() {
        try {
            List<StartupResponseDTO> startups = service.listarTodas();
            return ResponseEntity.ok(startups); // 200 OK (Retorna [] se vazio)
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao buscar a lista de startups."));
        }
    }

    // 🔹 READ BY ID (GET)
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        try {
            StartupResponseDTO startup = service.buscarPorId(id);
            return ResponseEntity.ok(startup); // 200 OK
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro interno ao buscar startup."));
        }
    }

    // 🔹 UPDATE (PUT)
    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @RequestBody StartupUpdateDTO dto) {
        try {
            StartupResponseDTO startupAtualizada = service.atualizar(id, dto);
            return ResponseEntity.ok(startupAtualizada); // 200 OK
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao atualizar os dados da startup."));
        }
    }

    // 🔹 DELETE (DELETE)
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        try {
            service.deletar(id);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build(); // 204 No Content
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao excluir a startup."));
        }
    }
}