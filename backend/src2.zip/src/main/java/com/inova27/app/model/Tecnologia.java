package com.inova27.app.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "tecnologias")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tecnologia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tecnologia")
    private Long id;

    @Column(nullable = false, length = 150)
    private String nome;

    @Column(length = 500)
    private String descricao;

    @Column(length = 100)
    private String area;

    @Column(name = "nivel_maturidade", length = 50)
    private String nivelMaturidade;

    @Column(length = 300)
    private String aplicacao;

    @Column(length = 50)
    private String status;

    // 🔹 Relacionamento N:N (Tecnologia <-> Pessoa)
    @ManyToMany(mappedBy = "tecnologias")
    private Set<Pessoa> pessoas = new HashSet<>();

    @OneToMany(mappedBy = "tecnologia", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Protecao> protecoes = new HashSet<>();
}