package com.inova27.app.service;


import com.inova27.app.dto.protecao.ProtecaoCreateDTO;
import com.inova27.app.dto.protecao.ProtecaoResponseDTO;
import com.inova27.app.dto.protecao.ProtecaoUpdateDTO;
import com.inova27.app.model.Jogo;
import com.inova27.app.model.Protecao;
import com.inova27.app.model.Tecnologia;
import com.inova27.app.repository.JogoRepository;
import com.inova27.app.repository.ProtecaoRepository;
import com.inova27.app.repository.TecnologiaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProtecaoService {

    @Autowired
    private ProtecaoRepository repository;

    @Autowired
    private TecnologiaRepository tecnologiaRepository;

    @Autowired
    private JogoRepository jogoRepository;

    // O TecnologiaRepository já deve estar aqui do passo anterior

    // 🔹 CREATE
    public ProtecaoResponseDTO criar(ProtecaoCreateDTO dto) {
        try {
            if (dto.nome() == null || dto.nome().isBlank()) {
                throw new IllegalArgumentException("O nome da proteção é obrigatório.");
            }

            // 🚨 AQUI ESTÁ A NOVA REGRA DE NEGÓCIO 🚨
            if (dto.tecnologiaId() == null && dto.jogoId() == null) {
                throw new IllegalArgumentException("A proteção deve estar vinculada obrigatoriamente a uma Tecnologia OU a um Jogo.");
            }

            if (dto.codId() != null && repository.existsByCodId(dto.codId())) {
                throw new IllegalArgumentException("Já existe uma proteção com este Código ID.");
            }

            Protecao protecao = new Protecao();
            protecao.setCodId(dto.codId());
            protecao.setNome(dto.nome());
            protecao.setResumo(dto.resumo());
            protecao.setInstituicao(dto.instituicao());
            protecao.setNatureza(dto.natureza());
            protecao.setDataDeposito(dto.dataDeposito());
            protecao.setInfoExtra(dto.infoExtra());
            if (dto.tipos() != null) protecao.setTipos(dto.tipos());

            // 🔹 Se enviou ID da Tecnologia, busca e vincula
            if (dto.tecnologiaId() != null) {
                Tecnologia tecnologia = tecnologiaRepository.findById(dto.tecnologiaId())
                        .orElseThrow(() -> new IllegalArgumentException("Tecnologia informada não encontrada."));
                protecao.setTecnologia(tecnologia);
            }

            // 🔹 Se enviou ID do Jogo, busca e vincula
            if (dto.jogoId() != null) {
                Jogo jogo = jogoRepository.findById(dto.jogoId())
                        .orElseThrow(() -> new IllegalArgumentException("Jogo informado não encontrado."));
                protecao.setJogo(jogo);
            }

            Protecao salva = repository.save(protecao);
            return toResponseDTO(salva);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao criar proteção: " + e.getMessage());
        }
    }

    // 🔹 READ ALL
    public List<ProtecaoResponseDTO> listarTodas() {
        try {
            return repository.findAll()
                    .stream()
                    .map(this::toResponseDTO)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar a lista de proteções: " + e.getMessage());
        }
    }

    // 🔹 READ BY ID
    public ProtecaoResponseDTO buscarPorId(Long id) {
        try {
            Protecao protecao = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Proteção não encontrada com o ID: " + id));
            return toResponseDTO(protecao);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao buscar proteção: " + e.getMessage());
        }
    }

    // 🔹 UPDATE
    public ProtecaoResponseDTO atualizar(Long id, ProtecaoUpdateDTO dto) {
        try {
            Protecao protecao = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Proteção não encontrada para atualização."));

            if (dto.codId() != null) protecao.setCodId(dto.codId());
            if (dto.nome() != null && !dto.nome().isBlank()) protecao.setNome(dto.nome());
            if (dto.resumo() != null) protecao.setResumo(dto.resumo());
            if (dto.instituicao() != null) protecao.setInstituicao(dto.instituicao());
            if (dto.natureza() != null) protecao.setNatureza(dto.natureza());
            if (dto.dataDeposito() != null) protecao.setDataDeposito(dto.dataDeposito());
            if (dto.infoExtra() != null) protecao.setInfoExtra(dto.infoExtra());
            if (dto.tipos() != null) protecao.setTipos(dto.tipos());

            Protecao atualizada = repository.save(protecao);
            return toResponseDTO(atualizada);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao atualizar proteção: " + e.getMessage());
        }
    }

    // 🔹 DELETE
    public void deletar(Long id) {
        try {
            Protecao protecao = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Proteção não encontrada para exclusão."));

            repository.delete(protecao);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao deletar proteção: " + e.getMessage());
        }
    }

    // 🔹 MAPPER
    private ProtecaoResponseDTO toResponseDTO(Protecao protecao) {
        return new ProtecaoResponseDTO(
                protecao.getId(),
                protecao.getCodId(),
                protecao.getNome(),
                protecao.getResumo(),
                protecao.getInstituicao(),
                protecao.getNatureza(),
                protecao.getDataDeposito(),
                protecao.getInfoExtra(),
                protecao.getTipos(),
                protecao.getTecnologia() != null ? protecao.getTecnologia().getId() : null, // 🔹 Evita NullPointerException
                protecao.getJogo() != null ? protecao.getJogo().getId() : null              // 🔹 Evita NullPointerException
        );
    }

    // ========================================================================
    // 🔹 GERENCIAMENTO DE RELACIONAMENTOS
    // ========================================================================

    // 1. JOGO (N:1 Opcional) - Vincular proteção a um jogo
    @Transactional
    public void vincularJogo(Long protecaoId, Long jogoId) {
        try {
            Protecao protecao = repository.findById(protecaoId)
                    .orElseThrow(() -> new IllegalArgumentException("Proteção não encontrada."));
            Jogo jogo = jogoRepository.findById(jogoId)
                    .orElseThrow(() -> new IllegalArgumentException("Jogo não encontrado."));

            protecao.setJogo(jogo);
            repository.save(protecao);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao vincular jogo: " + e.getMessage());
        }
    }

    @Transactional
    public void desvincularJogo(Long protecaoId, Long jogoId) {
        try {
            Protecao protecao = repository.findById(protecaoId)
                    .orElseThrow(() -> new IllegalArgumentException("Proteção não encontrada."));

            // Double Check
            if (protecao.getJogo() == null || !protecao.getJogo().getId().equals(jogoId)) {
                throw new IllegalArgumentException("Esta proteção não está vinculada a este jogo.");
            }

            protecao.setJogo(null);
            repository.save(protecao);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao desvincular jogo: " + e.getMessage());
        }
    }
}