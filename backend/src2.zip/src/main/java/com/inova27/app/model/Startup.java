package com.inova27.app.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "startups")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Startup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_startup")
    private Long id;

    @Column(nullable = false, length = 150)
    private String nome;

    @Column(length = 500)
    private String descricao;

    @Column(length = 100)
    private String area;

    @Column(name = "data_fundacao")
    private LocalDate dataFundacao;

    @Column(length = 200)
    private String site;

    @Column(length = 150)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusStartup status;

    // 🔹 Relacionamento N:N (Startup <-> Pessoa)
    @ManyToMany(mappedBy = "startups")
    private Set<Pessoa> pessoas = new HashSet<>();
}