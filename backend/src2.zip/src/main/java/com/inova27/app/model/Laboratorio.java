package com.inova27.app.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "laboratorios")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Laboratorio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_laboratorio")
    private Long id;

    @Column(nullable = false, length = 150)
    private String nome;

    @Column(length = 1000)
    private String descricao;

    @Column(length = 150)
    private String coordenacao;

    @Column(length = 100)
    private String area;

    @Column(length = 150)
    private String email;

    @Column(length = 200)
    private String site;

    @Column(length = 20)
    private String telefone;

    @Column(length = 100)
    private String natureza;

    @Column(length = 150)
    private String vinculado;

    @Column(length = 100)
    private String horario;

    @Column(length = 500)
    private String parcerias;

    @Column(length = 1000)
    private String infraestrutura;

    // 🔹 Tags (coleção simples)
    @ElementCollection
    @CollectionTable(name = "laboratorio_tags", joinColumns = @JoinColumn(name = "laboratorio_id"))
    @Column(name = "tag")
    private Set<String> tags = new HashSet<>();

    @OneToMany(mappedBy = "laboratorio", cascade = CascadeType.ALL)
    private Set<Pessoa> pessoas = new HashSet<>();
}