package com.inova27.app.dto.authentication;

public record LoginResponseDTO(String token) {
}