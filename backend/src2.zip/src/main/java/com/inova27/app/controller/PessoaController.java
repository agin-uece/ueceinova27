package com.inova27.app.controller;

import com.inova27.app.dto.pessoa.PessoaCreateDTO;
import com.inova27.app.dto.pessoa.PessoaResponseDTO;
import com.inova27.app.dto.pessoa.PessoaUpdateDTO;
import com.inova27.app.service.PessoaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/pessoas")
public class PessoaController {

    @Autowired
    private PessoaService service;

    // 🔹 CREATE (POST)
    @PostMapping
    public ResponseEntity<?> criar(@RequestBody PessoaCreateDTO dto) {
        try {
            PessoaResponseDTO novaPessoa = service.criar(dto);
            return ResponseEntity.status(HttpStatus.CREATED).body(novaPessoa); // 201 Created
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("erro", e.getMessage())); // 400 Bad Request
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Ocorreu um erro ao processar a requisição.")); // 500
        }
    }

    // 🔹 READ ALL (GET)
    @GetMapping
    public ResponseEntity<?> listarTodas() {
        try {
            List<PessoaResponseDTO> pessoas = service.listarTodas();
            return ResponseEntity.ok(pessoas); // 200 OK
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", e.getMessage()));
        }
    }

    // 🔹 READ BY ID (GET)
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        try {
            PessoaResponseDTO pessoa = service.buscarPorId(id);
            return ResponseEntity.ok(pessoa); // 200 OK
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404 Not Found
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", e.getMessage()));
        }
    }

    // 🔹 UPDATE (PUT)
    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @RequestBody PessoaUpdateDTO dto) {
        try {
            PessoaResponseDTO pessoaAtualizada = service.atualizar(id, dto);
            return ResponseEntity.ok(pessoaAtualizada); // 200 OK
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404 Not Found
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao atualizar os dados."));
        }
    }

    // 🔹 DELETE (DELETE)
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        try {
            service.deletar(id);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build(); // 204 No Content (Deletado com sucesso, sem corpo)
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404 Not Found
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao excluir a pessoa."));
        }
    }

    // ========================================================================
    // 🔹 ENDPOINTS DE RELACIONAMENTOS
    // ========================================================================

    // 🔬 LABORATÓRIO
    @PutMapping("/{pessoaId}/laboratorio/{laboratorioId}")
    public ResponseEntity<?> vincularLaboratorio(@PathVariable Long pessoaId, @PathVariable Long laboratorioId) {
        try {
            service.vincularLaboratorio(pessoaId, laboratorioId);
            return ResponseEntity.ok(Map.of("mensagem", "Laboratório vinculado com sucesso."));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", e.getMessage()));
        }
    }

    @DeleteMapping("/{pessoaId}/laboratorio/{laboratorioId}")
    public ResponseEntity<?> desvincularLaboratorio(@PathVariable Long pessoaId, @PathVariable Long laboratorioId) {
        try {
            service.desvincularLaboratorio(pessoaId, laboratorioId);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", e.getMessage()));
        }
    }

    // 🚀 STARTUPS
    @PutMapping("/{pessoaId}/startups/{startupId}")
    public ResponseEntity<?> vincularStartup(@PathVariable Long pessoaId, @PathVariable Long startupId) {
        try {
            service.vincularStartup(pessoaId, startupId);
            return ResponseEntity.ok(Map.of("mensagem", "Startup vinculada com sucesso."));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", e.getMessage()));
        }
    }

    @DeleteMapping("/{pessoaId}/startups/{startupId}")
    public ResponseEntity<?> desvincularStartup(@PathVariable Long pessoaId, @PathVariable Long startupId) {
        try {
            service.desvincularStartup(pessoaId, startupId);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", e.getMessage()));
        }
    }

    // 💻 TECNOLOGIAS
    @PutMapping("/{pessoaId}/tecnologias/{tecnologiaId}")
    public ResponseEntity<?> vincularTecnologia(@PathVariable Long pessoaId, @PathVariable Long tecnologiaId) {
        try {
            service.vincularTecnologia(pessoaId, tecnologiaId);
            return ResponseEntity.ok(Map.of("mensagem", "Tecnologia vinculada com sucesso."));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", e.getMessage()));
        }
    }

    @DeleteMapping("/{pessoaId}/tecnologias/{tecnologiaId}")
    public ResponseEntity<?> desvincularTecnologia(@PathVariable Long pessoaId, @PathVariable Long tecnologiaId) {
        try {
            service.desvincularTecnologia(pessoaId, tecnologiaId);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", e.getMessage()));
        }
    }
}