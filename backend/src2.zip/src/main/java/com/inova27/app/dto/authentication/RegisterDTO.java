package com.inova27.app.dto.authentication;


import com.inova27.app.model.UserRole;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record RegisterDTO(
        @NotBlank(message = "O login não pode estar vazio") String login,
        @NotBlank(message = "A senha não pode estar vazia") String senha,
        @NotNull(message = "A permissão (role) é obrigatória") UserRole role
) {}