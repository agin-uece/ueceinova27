package com.inova27.app.service;

import com.inova27.app.dto.laboratorio.LaboratorioCreateDTO;
import com.inova27.app.dto.laboratorio.LaboratorioResponseDTO;
import com.inova27.app.dto.laboratorio.LaboratorioUpdateDTO;
import com.inova27.app.model.Laboratorio;
import com.inova27.app.repository.LaboratorioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LaboratorioService {

    @Autowired
    private LaboratorioRepository repository;

    // 🔹 CREATE
    public LaboratorioResponseDTO criar(LaboratorioCreateDTO dto) {
        try {

            if (dto.nome() == null || dto.nome().isBlank()) {
                throw new RuntimeException("Nome é obrigatório");
            }

            if (repository.existsByNome(dto.nome())) {
                throw new RuntimeException("Já existe um laboratório com esse nome");
            }

            Laboratorio lab = new Laboratorio();

            lab.setNome(dto.nome());
            lab.setDescricao(dto.descricao());
            lab.setCoordenacao(dto.coordenacao());
            lab.setArea(dto.area());
            lab.setEmail(dto.email());
            lab.setSite(dto.site());
            lab.setTelefone(dto.telefone());
            lab.setNatureza(dto.natureza());
            lab.setVinculado(dto.vinculado());
            lab.setHorario(dto.horario());
            lab.setParcerias(dto.parcerias());
            lab.setInfraestrutura(dto.infraestrutura());

            if (dto.tags() != null) {
                lab.setTags(dto.tags());
            }

            return toResponse(repository.save(lab));

        } catch (Exception e) {
            throw new RuntimeException("Erro ao criar laboratório: " + e.getMessage());
        }
    }

    // 🔹 READ ALL
    public List<LaboratorioResponseDTO> listarTodos() {
        try {
            return repository.findAll()
                    .stream()
                    .map(this::toResponse)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Erro ao listar laboratórios");
        }
    }

    // 🔹 READ BY ID
    public LaboratorioResponseDTO buscarPorId(Long id) {
        try {
            Laboratorio lab = repository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Laboratório não encontrado"));

            return toResponse(lab);

        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar laboratório");
        }
    }

    // 🔹 UPDATE
    public LaboratorioResponseDTO atualizar(Long id, LaboratorioUpdateDTO dto) {
        try {

            Laboratorio lab = repository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Laboratório não encontrado"));

            if (dto.nome() != null && !dto.nome().isBlank()) {
                lab.setNome(dto.nome());
            }

            if (dto.descricao() != null) lab.setDescricao(dto.descricao());
            if (dto.coordenacao() != null) lab.setCoordenacao(dto.coordenacao());
            if (dto.area() != null) lab.setArea(dto.area());
            if (dto.email() != null) lab.setEmail(dto.email());
            if (dto.site() != null) lab.setSite(dto.site());
            if (dto.telefone() != null) lab.setTelefone(dto.telefone());
            if (dto.natureza() != null) lab.setNatureza(dto.natureza());
            if (dto.vinculado() != null) lab.setVinculado(dto.vinculado());
            if (dto.horario() != null) lab.setHorario(dto.horario());
            if (dto.parcerias() != null) lab.setParcerias(dto.parcerias());
            if (dto.infraestrutura() != null) lab.setInfraestrutura(dto.infraestrutura());

            if (dto.tags() != null) {
                lab.setTags(dto.tags());
            }

            return toResponse(repository.save(lab));

        } catch (Exception e) {
            throw new RuntimeException("Erro ao atualizar laboratório");
        }
    }

    // 🔹 DELETE
    public void deletar(Long id) {
        try {

            Laboratorio lab = repository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Laboratório não encontrado"));

            repository.delete(lab);

        } catch (Exception e) {
            throw new RuntimeException("Erro ao deletar laboratório");
        }
    }

    // 🔹 Mapper
    private LaboratorioResponseDTO toResponse(Laboratorio lab) {
        return new LaboratorioResponseDTO(
                lab.getId(),
                lab.getNome(),
                lab.getDescricao(),
                lab.getCoordenacao(),
                lab.getArea(),
                lab.getEmail(),
                lab.getSite(),
                lab.getTelefone(),
                lab.getNatureza(),
                lab.getVinculado(),
                lab.getHorario(),
                lab.getParcerias(),
                lab.getInfraestrutura(),
                lab.getTags()
        );
    }
}