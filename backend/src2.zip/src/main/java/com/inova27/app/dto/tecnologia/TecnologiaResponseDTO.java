package com.inova27.app.dto.tecnologia;

public record TecnologiaResponseDTO(
        Long id,
        String nome,
        String descricao,
        String area,
        String nivelMaturidade,
        String aplicacao,
        String status
) {}