package com.inova27.app.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "pessoas")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Pessoa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 150)
    private String nome;

    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @Column(length = 20)
    private String telefone;

    @Column(name = "area_pesquisa", length = 150)
    private String areaPesquisa;

    @Column(length = 100)
    private String titulacao;

    @Column(length = 150)
    private String instituicao;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Papel papel;

    // 🔹 Relacionamento N:N (Pessoa <-> Startup)
    @ManyToMany
    @JoinTable(
            name = "pessoa_startup",
            joinColumns = @JoinColumn(name = "pessoa_id"),
            inverseJoinColumns = @JoinColumn(name = "startup_id")
    )
    private Set<Startup> startups = new HashSet<>();

    // 🔹 Relacionamento N:N (Pessoa <-> Tecnologia)
    @ManyToMany
    @JoinTable(
            name = "pessoa_tecnologia",
            joinColumns = @JoinColumn(name = "pessoa_id"),
            inverseJoinColumns = @JoinColumn(name = "tecnologia_id")
    )
    private Set<Tecnologia> tecnologias = new HashSet<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "laboratorio_id")
    private Laboratorio laboratorio;
}