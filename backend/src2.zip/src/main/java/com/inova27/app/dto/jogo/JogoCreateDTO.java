package com.inova27.app.dto.jogo;

import com.inova27.app.model.GeneroJogo;
import com.inova27.app.model.Plataforma;
import java.time.LocalDate;

public record JogoCreateDTO(
        String nome,
        String descricao,
        GeneroJogo genero,
        Plataforma plataforma,
        LocalDate dataLancamento,
        String linkDownload,
        String site
) {}