package com.inova27.app.dto.pessoa;

import com.inova27.app.model.Papel;

public record PessoaUpdateDTO(
        String nome,
        String telefone,
        String areaPesquisa,
        String titulacao,
        String instituicao,
        Papel papel
) {}