package com.inova27.app.service;

import com.inova27.app.dto.startup.StartupCreateDTO;
import com.inova27.app.dto.startup.StartupResponseDTO;
import com.inova27.app.dto.startup.StartupUpdateDTO;
import com.inova27.app.model.Startup;
import com.inova27.app.repository.StartupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class StartupService {

    @Autowired
    private StartupRepository repository;

    // 🔹 CREATE
    public StartupResponseDTO criar(StartupCreateDTO dto) {
        try {
            if (dto.nome() == null || dto.nome().isBlank()) {
                throw new IllegalArgumentException("O nome da startup é obrigatório.");
            }
            if (repository.existsByNome(dto.nome())) {
                throw new IllegalArgumentException("Já existe uma startup cadastrada com este nome.");
            }

            Startup startup = new Startup();
            startup.setNome(dto.nome());
            startup.setDescricao(dto.descricao());
            startup.setArea(dto.area());
            startup.setDataFundacao(dto.dataFundacao());
            startup.setSite(dto.site());
            startup.setEmail(dto.email());
            startup.setStatus(dto.status());

            Startup salva = repository.save(startup);
            return toResponseDTO(salva);

        } catch (IllegalArgumentException e) {
            throw e; // Repassa validações de negócio
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao criar startup: " + e.getMessage());
        }
    }

    // 🔹 READ ALL
    public List<StartupResponseDTO> listarTodas() {
        try {
            return repository.findAll()
                    .stream()
                    .map(this::toResponseDTO)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar a lista de startups: " + e.getMessage());
        }
    }

    // 🔹 READ BY ID
    public StartupResponseDTO buscarPorId(Long id) {
        try {
            Startup startup = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Startup não encontrada com o ID: " + id));
            return toResponseDTO(startup);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao buscar startup: " + e.getMessage());
        }
    }

    // 🔹 UPDATE
    public StartupResponseDTO atualizar(Long id, StartupUpdateDTO dto) {
        try {
            Startup startup = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Startup não encontrada para atualização."));

            if (dto.nome() != null && !dto.nome().isBlank()) startup.setNome(dto.nome());
            if (dto.descricao() != null) startup.setDescricao(dto.descricao());
            if (dto.area() != null) startup.setArea(dto.area());
            if (dto.dataFundacao() != null) startup.setDataFundacao(dto.dataFundacao());
            if (dto.site() != null) startup.setSite(dto.site());
            if (dto.email() != null) startup.setEmail(dto.email());
            if (dto.status() != null) startup.setStatus(dto.status());

            Startup atualizada = repository.save(startup);
            return toResponseDTO(atualizada);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao atualizar startup: " + e.getMessage());
        }
    }

    // 🔹 DELETE
    public void deletar(Long id) {
        try {
            Startup startup = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Startup não encontrada para exclusão."));

            repository.delete(startup);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao deletar startup: " + e.getMessage());
        }
    }

    // 🔹 MAPPER
    private StartupResponseDTO toResponseDTO(Startup startup) {
        return new StartupResponseDTO(
                startup.getId(),
                startup.getNome(),
                startup.getDescricao(),
                startup.getArea(),
                startup.getDataFundacao(),
                startup.getSite(),
                startup.getEmail(),
                startup.getStatus()
        );
    }
}