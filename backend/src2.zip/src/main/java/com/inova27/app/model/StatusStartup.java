package com.inova27.app.model;

public enum StatusStartup {
    ATIVA,
    INATIVA,
    EM_DESENVOLVIMENTO,
    ENCERRADA
}