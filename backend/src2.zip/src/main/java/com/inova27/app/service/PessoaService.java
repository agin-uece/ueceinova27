package com.inova27.app.service;

import com.inova27.app.dto.pessoa.PessoaCreateDTO;
import com.inova27.app.dto.pessoa.PessoaResponseDTO;
import com.inova27.app.dto.pessoa.PessoaUpdateDTO;
import com.inova27.app.model.Laboratorio;
import com.inova27.app.model.Pessoa;
import com.inova27.app.model.Startup;
import com.inova27.app.model.Tecnologia;
import com.inova27.app.repository.LaboratorioRepository;
import com.inova27.app.repository.PessoaRepository;
import com.inova27.app.repository.StartupRepository;
import com.inova27.app.repository.TecnologiaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PessoaService {

    @Autowired
    private PessoaRepository repository;

    @Autowired
    private LaboratorioRepository laboratorioRepository;

    @Autowired
    private StartupRepository startupRepository;

    @Autowired
    private TecnologiaRepository tecnologiaRepository;

    // 🔹 CREATE
    public PessoaResponseDTO criar(PessoaCreateDTO dto) {
        try {
            if (repository.existsByEmail(dto.email())) {
                throw new IllegalArgumentException("Já existe uma pessoa cadastrada com este e-mail.");
            }

            Pessoa pessoa = new Pessoa();
            pessoa.setNome(dto.nome());
            pessoa.setEmail(dto.email());
            pessoa.setTelefone(dto.telefone());
            pessoa.setAreaPesquisa(dto.areaPesquisa());
            pessoa.setTitulacao(dto.titulacao());
            pessoa.setInstituicao(dto.instituicao());
            pessoa.setPapel(dto.papel());

            Pessoa salva = repository.save(pessoa);
            return toResponseDTO(salva);

        } catch (IllegalArgumentException e) {
            throw e; // Repassa a exceção de negócio para o Controller tratar
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao criar pessoa: " + e.getMessage());
        }
    }

    // 🔹 READ ALL
    public List<PessoaResponseDTO> listarTodas() {
        try {
            return repository.findAll()
                    .stream()
                    .map(this::toResponseDTO)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar a lista de pessoas: " + e.getMessage());
        }
    }

    // 🔹 READ BY ID
    public PessoaResponseDTO buscarPorId(Long id) {
        try {
            Pessoa pessoa = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Pessoa não encontrada com o ID: " + id));
            return toResponseDTO(pessoa);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao buscar pessoa: " + e.getMessage());
        }
    }

    // 🔹 UPDATE
    public PessoaResponseDTO atualizar(Long id, PessoaUpdateDTO dto) {
        try {
            Pessoa pessoa = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Pessoa não encontrada para atualização."));

            if (dto.nome() != null) pessoa.setNome(dto.nome());
            if (dto.telefone() != null) pessoa.setTelefone(dto.telefone());
            if (dto.areaPesquisa() != null) pessoa.setAreaPesquisa(dto.areaPesquisa());
            if (dto.titulacao() != null) pessoa.setTitulacao(dto.titulacao());
            if (dto.instituicao() != null) pessoa.setInstituicao(dto.instituicao());
            if (dto.papel() != null) pessoa.setPapel(dto.papel());

            Pessoa atualizada = repository.save(pessoa);
            return toResponseDTO(atualizada);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao atualizar pessoa: " + e.getMessage());
        }
    }

    // 🔹 DELETE
    public void deletar(Long id) {
        try {
            Pessoa pessoa = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Pessoa não encontrada para exclusão."));

            repository.delete(pessoa);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao deletar pessoa: " + e.getMessage());
        }
    }

    // 🔹 MAPPER (Converte a Entidade para DTO)
    private PessoaResponseDTO toResponseDTO(Pessoa pessoa) {
        return new PessoaResponseDTO(
                pessoa.getId(),
                pessoa.getNome(),
                pessoa.getEmail(),
                pessoa.getTelefone(),
                pessoa.getAreaPesquisa(),
                pessoa.getTitulacao(),
                pessoa.getInstituicao(),
                pessoa.getPapel()
        );
    }

    // ========================================================================
    // 🔹 GERENCIAMENTO DE RELACIONAMENTOS
    // ========================================================================

    // 1. LABORATÓRIO (N:1) - Uma pessoa pertence a um laboratório
    public void vincularLaboratorio(Long pessoaId, Long laboratorioId) {
        try {
            Pessoa pessoa = repository.findById(pessoaId)
                    .orElseThrow(() -> new IllegalArgumentException("Pessoa não encontrada."));
            Laboratorio laboratorio = laboratorioRepository.findById(laboratorioId)
                    .orElseThrow(() -> new IllegalArgumentException("Laboratório não encontrado."));

            pessoa.setLaboratorio(laboratorio);
            repository.save(pessoa);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao vincular laboratório: " + e.getMessage());
        }
    }

    public void desvincularLaboratorio(Long pessoaId, Long laboratorioId) {
        try {
            Pessoa pessoa = repository.findById(pessoaId)
                    .orElseThrow(() -> new IllegalArgumentException("Pessoa não encontrada."));

            // 🔹 Double Check: Verifica se a pessoa realmente está neste laboratório
            if (pessoa.getLaboratorio() == null || !pessoa.getLaboratorio().getId().equals(laboratorioId)) {
                throw new IllegalArgumentException("Esta pessoa não está vinculada a este laboratório (ID incompatível).");
            }

            pessoa.setLaboratorio(null);
            repository.save(pessoa);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao desvincular laboratório: " + e.getMessage());
        }
    }

    // 2. STARTUPS (N:N) - Uma pessoa faz parte de várias startups e vice-versa
    @Transactional
    public void vincularStartup(Long pessoaId, Long startupId) {
        try {
            Pessoa pessoa = repository.findById(pessoaId)
                    .orElseThrow(() -> new IllegalArgumentException("Pessoa não encontrada."));
            Startup startup = startupRepository.findById(startupId)
                    .orElseThrow(() -> new IllegalArgumentException("Startup não encontrada."));

            // 🔹 Agora adicionamos à lista, igual fizemos com Tecnologia
            pessoa.getStartups().add(startup);
            repository.save(pessoa);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao vincular startup: " + e.getMessage());
        }
    }

    @Transactional
    public void desvincularStartup(Long pessoaId, Long startupId) {
        try {
            Pessoa pessoa = repository.findById(pessoaId)
                    .orElseThrow(() -> new IllegalArgumentException("Pessoa não encontrada."));

            // 🔹 1. Proteção contra NullPointerException
            if (pessoa.getStartups() == null) {
                throw new IllegalArgumentException("A pessoa não possui nenhuma startup vinculada.");
            }

            // 🔹 2. Remoção segura filtrando pelo ID (Evita bugs do JPA)
            boolean removido = pessoa.getStartups().removeIf(s -> s.getId().equals(startupId));

            if (!removido) {
                throw new IllegalArgumentException("Esta startup não estava vinculada a esta pessoa.");
            }

            repository.save(pessoa);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            String causa = e.getMessage() != null ? e.getMessage() : "Erro interno de referência nula.";
            throw new RuntimeException("Erro ao desvincular startup: " + causa);
        }
    }

    // 3. TECNOLOGIAS (N:N) - Uma pessoa tem várias tecnologias e vice-versa
    public void vincularTecnologia(Long pessoaId, Long tecnologiaId) {
        try {
            Pessoa pessoa = repository.findById(pessoaId)
                    .orElseThrow(() -> new IllegalArgumentException("Pessoa não encontrada."));
            Tecnologia tecnologia = tecnologiaRepository.findById(tecnologiaId)
                    .orElseThrow(() -> new IllegalArgumentException("Tecnologia não encontrada."));

            pessoa.getTecnologias().add(tecnologia);
            repository.save(pessoa);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao vincular tecnologia: " + e.getMessage());
        }
    }

    public void desvincularTecnologia(Long pessoaId, Long tecnologiaId) {
        try {
            Pessoa pessoa = repository.findById(pessoaId)
                    .orElseThrow(() -> new IllegalArgumentException("Pessoa não encontrada."));
            Tecnologia tecnologia = tecnologiaRepository.findById(tecnologiaId)
                    .orElseThrow(() -> new IllegalArgumentException("Tecnologia não encontrada."));

            pessoa.getTecnologias().remove(tecnologia);
            repository.save(pessoa);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao desvincular tecnologia: " + e.getMessage());
        }
    }
}