package com.inova27.app.dto.protecao;

import com.inova27.app.model.NaturezaProtecao;
import com.inova27.app.model.TipoProtecao;
import java.time.LocalDate;
import java.util.Set;

public record ProtecaoCreateDTO(
        String codId,
        String nome,
        String resumo,
        String instituicao,
        NaturezaProtecao natureza,
        LocalDate dataDeposito,
        String infoExtra,
        Set<TipoProtecao> tipos,
        Long tecnologiaId, // 🔹 Deixou de ser obrigatório
        Long jogoId        // 🔹 Adicionado para permitir criar atrelado ao Jogo
) {}