package com.inova27.app.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private SecurityFilter securityFilter;

    @Autowired
    private CustomAccessDeniedHandler customAccessDeniedHandler;


    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        return httpSecurity
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(authorize -> authorize
                        .anyRequest().permitAll()
                )
                .build();
    }

//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
//        return httpSecurity
//                .csrf(csrf -> csrf.disable())
//                .authorizeHttpRequests(authorize -> authorize
//
//                        // PATENTES
//                        .requestMatchers(HttpMethod.GET, "/patentes")
//                        .hasAnyAuthority("ROLE_ADMIN", "ROLE_COMUM")
//
//                        .requestMatchers(HttpMethod.POST, "/patentes")
//                        .hasAuthority("ROLE_ADMIN")
//
//                        .requestMatchers(HttpMethod.PUT, "/patentes/*")
//                        .hasAuthority("ROLE_ADMIN")
//
//                        .requestMatchers(HttpMethod.DELETE, "/patentes/*")
//                        .hasAuthority("ROLE_ADMIN")
//
//
//                        // LABORATORIOS
//
//                        .requestMatchers(HttpMethod.POST, "/laboratorios")
//                        .hasAuthority("ROLE_ADMIN")
//
//                        .requestMatchers(HttpMethod.PUT, "/laboratorios/**")
//                        .hasAuthority("ROLE_ADMIN")
//
//                        .requestMatchers(HttpMethod.DELETE, "/laboratorios/**")
//                        .hasAuthority("ROLE_ADMIN")
//
//                        .requestMatchers(HttpMethod.GET, "/laboratorios/**")
//                        .hasAnyAuthority("ROLE_ADMIN", "ROLE_COMUM")
//
//                        // autenticação
//
//                        .requestMatchers(HttpMethod.POST, "/auth/register").hasAuthority("ROLE_ADMIN")
//
//                        .requestMatchers(HttpMethod.POST, "/auth/login").permitAll()
//
//                        .anyRequest().authenticated()
//                )
//                .exceptionHandling(exception -> exception
//                        .accessDeniedHandler(customAccessDeniedHandler)
//                )
//                .addFilterBefore(securityFilter, UsernamePasswordAuthenticationFilter.class)
//                .build();
//    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        // Usa o BCrypt para criptografar as senhas no banco
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }
}