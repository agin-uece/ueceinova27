package com.inova27.app.service;

import com.inova27.app.dto.tecnologia.TecnologiaUpdateDTO;
import com.inova27.app.dto.tecnologia.TecnologiaCreateDTO;
import com.inova27.app.dto.tecnologia.TecnologiaResponseDTO;
import com.inova27.app.model.Tecnologia;
import com.inova27.app.repository.TecnologiaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TecnologiaService {

    @Autowired
    private TecnologiaRepository repository;

    // 🔹 CREATE
    public TecnologiaResponseDTO criar(TecnologiaCreateDTO dto) {
        try {
            if (dto.nome() == null || dto.nome().isBlank()) {
                throw new IllegalArgumentException("O nome da tecnologia é obrigatório.");
            }
            if (repository.existsByNome(dto.nome())) {
                throw new IllegalArgumentException("Já existe uma tecnologia cadastrada com este nome.");
            }

            Tecnologia tecnologia = new Tecnologia();
            tecnologia.setNome(dto.nome());
            tecnologia.setDescricao(dto.descricao());
            tecnologia.setArea(dto.area());
            tecnologia.setNivelMaturidade(dto.nivelMaturidade());
            tecnologia.setAplicacao(dto.aplicacao());
            tecnologia.setStatus(dto.status());

            Tecnologia salva = repository.save(tecnologia);
            return toResponseDTO(salva);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao criar tecnologia: " + e.getMessage());
        }
    }

    // 🔹 READ ALL
    public List<TecnologiaResponseDTO> listarTodas() {
        try {
            return repository.findAll()
                    .stream()
                    .map(this::toResponseDTO)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar a lista de tecnologias: " + e.getMessage());
        }
    }

    // 🔹 READ BY ID
    public TecnologiaResponseDTO buscarPorId(Long id) {
        try {
            Tecnologia tecnologia = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Tecnologia não encontrada com o ID: " + id));
            return toResponseDTO(tecnologia);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao buscar tecnologia: " + e.getMessage());
        }
    }

    // 🔹 UPDATE
    public TecnologiaResponseDTO atualizar(Long id, TecnologiaUpdateDTO dto) {
        try {
            Tecnologia tecnologia = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Tecnologia não encontrada para atualização."));

            if (dto.nome() != null && !dto.nome().isBlank()) tecnologia.setNome(dto.nome());
            if (dto.descricao() != null) tecnologia.setDescricao(dto.descricao());
            if (dto.area() != null) tecnologia.setArea(dto.area());
            if (dto.nivelMaturidade() != null) tecnologia.setNivelMaturidade(dto.nivelMaturidade());
            if (dto.aplicacao() != null) tecnologia.setAplicacao(dto.aplicacao());
            if (dto.status() != null) tecnologia.setStatus(dto.status());

            Tecnologia atualizada = repository.save(tecnologia);
            return toResponseDTO(atualizada);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao atualizar tecnologia: " + e.getMessage());
        }
    }

    // 🔹 DELETE
    public void deletar(Long id) {
        try {
            Tecnologia tecnologia = repository.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Tecnologia não encontrada para exclusão."));

            repository.delete(tecnologia);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro interno ao deletar tecnologia: " + e.getMessage());
        }
    }

    // 🔹 MAPPER
    private TecnologiaResponseDTO toResponseDTO(Tecnologia tecnologia) {
        return new TecnologiaResponseDTO(
                tecnologia.getId(),
                tecnologia.getNome(),
                tecnologia.getDescricao(),
                tecnologia.getArea(),
                tecnologia.getNivelMaturidade(),
                tecnologia.getAplicacao(),
                tecnologia.getStatus()
        );
    }
}