package com.inova27.app.controller;

import com.inova27.app.dto.tecnologia.TecnologiaUpdateDTO;
import com.inova27.app.dto.tecnologia.TecnologiaCreateDTO;
import com.inova27.app.dto.tecnologia.TecnologiaResponseDTO;
import com.inova27.app.service.TecnologiaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/tecnologias")
public class TecnologiaController {

    @Autowired
    private TecnologiaService service;

    // 🔹 CREATE (POST)
    @PostMapping
    public ResponseEntity<?> criar(@RequestBody TecnologiaCreateDTO dto) {
        try {
            TecnologiaResponseDTO novaTecnologia = service.criar(dto);
            return ResponseEntity
                    .created(URI.create("/api/tecnologias/" + novaTecnologia.id()))
                    .body(novaTecnologia); // 201 Created
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("erro", e.getMessage())); // 400
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Ocorreu um erro ao processar a requisição.")); // 500
        }
    }

    // 🔹 READ ALL (GET)
    @GetMapping
    public ResponseEntity<?> listarTodas() {
        try {
            List<TecnologiaResponseDTO> tecnologias = service.listarTodas();
            return ResponseEntity.ok(tecnologias); // 200 OK (Retorna [] se vazio)
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao buscar a lista de tecnologias.")); // 500
        }
    }

    // 🔹 READ BY ID (GET)
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        try {
            TecnologiaResponseDTO tecnologia = service.buscarPorId(id);
            return ResponseEntity.ok(tecnologia); // 200 OK
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro interno ao buscar tecnologia.")); // 500
        }
    }

    // 🔹 UPDATE (PUT)
    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @RequestBody TecnologiaUpdateDTO dto) {
        try {
            TecnologiaResponseDTO tecnologiaAtualizada = service.atualizar(id, dto);
            return ResponseEntity.ok(tecnologiaAtualizada); // 200 OK
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao atualizar os dados da tecnologia.")); // 500
        }
    }

    // 🔹 DELETE (DELETE)
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        try {
            service.deletar(id);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build(); // 204 No Content
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("erro", e.getMessage())); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("erro", "Erro ao excluir a tecnologia.")); // 500
        }
    }
}