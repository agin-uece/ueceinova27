package com.inova27.app.dto.tecnologia;

public record TecnologiaCreateDTO(
        String nome,
        String descricao,
        String area,
        String nivelMaturidade,
        String aplicacao,
        String status
) {}