package com.inova27.app.model;

public enum Papel {
    ALUNO,
    PESQUISADOR,
    SERVIDOR,
    PESSOA_EXTERNA
}