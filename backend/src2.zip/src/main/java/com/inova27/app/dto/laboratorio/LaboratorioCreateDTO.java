package com.inova27.app.dto.laboratorio;

import java.util.Set;

public record LaboratorioCreateDTO(
        String nome,
        String descricao,
        String coordenacao,
        String area,
        String email,
        String site,
        String telefone,
        String natureza,
        String vinculado,
        String horario,
        String parcerias,
        String infraestrutura,
        Set<String> tags
) {}