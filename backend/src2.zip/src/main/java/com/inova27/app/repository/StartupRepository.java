package com.inova27.app.repository;

import com.inova27.app.model.Startup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StartupRepository extends JpaRepository<Startup, Long> {
    boolean existsByNome(String nome);
}