package com.inova27.app.dto.authentication;

import jakarta.validation.constraints.NotBlank;

public record AuthenticationDTO(
        @NotBlank(message = "O login não pode estar vazio") String login,
        @NotBlank(message = "A senha não pode estar vazia") String senha
) {}
