package com.inova27.app.dto.startup;

import com.inova27.app.model.StatusStartup;
import java.time.LocalDate;

public record StartupResponseDTO(
        Long id,
        String nome,
        String descricao,
        String area,
        LocalDate dataFundacao,
        String site,
        String email,
        StatusStartup status
) {}