package com.inova27.app.controller;


import com.inova27.app.dto.authentication.AuthenticationDTO;
import com.inova27.app.dto.authentication.LoginResponseDTO;
import com.inova27.app.dto.authentication.RegisterDTO;
import com.inova27.app.model.Usuario;
import com.inova27.app.repository.UsuarioRepository;
import com.inova27.app.service.TokenService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthenticationController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UsuarioRepository repository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private TokenService tokenService;

    @PostMapping("/login")
    public ResponseEntity login(@RequestBody @Valid AuthenticationDTO data) {
        try {
            var usernamePassword = new UsernamePasswordAuthenticationToken(data.login(), data.senha());

            // Se as credenciais estiverem erradas, o Spring lança uma exceção nesta linha
            var auth = this.authenticationManager.authenticate(usernamePassword);

            // Se passou, gera o token normalmente
            var token = tokenService.gerarToken((Usuario) auth.getPrincipal());
            return ResponseEntity.ok(new LoginResponseDTO(token));

        } catch (BadCredentialsException e) {
            // Captura especificamente o erro de credenciais inválidas (senha errada)
            // Por segurança, a mensagem deve ser genérica ("Usuário ou senha") para não dar dicas a invasores
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Erro: Usuário ou senha inválidos.");

        } catch (AuthenticationException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Erro: Falha na autenticação.");
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> registrar(@RequestBody @Valid RegisterDTO data) {
        try {
            // Validação 1: Verifica se o login já existe no banco
            if (this.repository.findByLogin(data.login()) != null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erro: Este login já está em uso.");
            }

            // Se não existir, cria o novo usuário
            Usuario novoUsuario = new Usuario();
            novoUsuario.setLogin(data.login());
            novoUsuario.setSenha(passwordEncoder.encode(data.senha()));
            novoUsuario.setRole(data.role());

            this.repository.save(novoUsuario);

            return ResponseEntity.status(HttpStatus.CREATED).body("Usuário registrado com sucesso!");

        } catch (DataIntegrityViolationException e) {
            // Captura erros estruturais do banco (ex: requisições simultâneas burlando o if e violando a constraint UNIQUE)
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Erro: Conflito de dados ao tentar registrar o usuário. O login pode já ter sido reservado.");

        } catch (Exception e) {
            // Captura qualquer outro erro inesperado (ex: o banco de dados perdeu a conexão no meio do processo)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro interno no servidor ao registrar usuário. Tente novamente mais tarde.");
        }
    }
}
